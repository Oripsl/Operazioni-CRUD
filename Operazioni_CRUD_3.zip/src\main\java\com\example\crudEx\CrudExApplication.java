package com.example.crudEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudExApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudExApplication.class, args);
	}

}
